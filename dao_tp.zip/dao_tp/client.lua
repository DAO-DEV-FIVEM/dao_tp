-- Importer NativeUI
local NativeUI = require("NativeUI")

local npcModel = "a_m_m_business_01"  -- Modèle du NPC
local npcCoords = vector3(100.0, -200.0, 30.0)  -- Coordonnées du NPC
local menuOpen = false

local locations = {
    {name = "Plage", coords = vector3(200.0, -1000.0, 30.0)},
    {name = "Montagne", coords = vector3(1500.0, 1000.0, 50.0)},
    {name = "Centre-ville", coords = vector3(500.0, -500.0, 30.0)}
}

-- Créer le NPC
Citizen.CreateThread(function()
    RequestModel(npcModel)
    while not HasModelLoaded(npcModel) do
        Wait(500)
    end

    local npcPed = CreatePed(4, npcModel, npcCoords.x, npcCoords.y, npcCoords.z, 0.0, true, true)

    -- Ajouter l'interaction
    while true do
        Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        local distance = GetDistanceBetweenCoords(playerCoords, npcCoords.x, npcCoords.y, npcCoords.z, true)

        if distance < 2.0 then
            DrawText3D(npcCoords.x, npcCoords.y, npcCoords.z, "[E] Interagir avec le NPC")
            if IsControlJustPressed(0, 38) then -- Touche 'E'
                OpenTeleportMenu()
            end
        end
    end
end)

-- Fonction pour ouvrir le menu
function OpenTeleportMenu()
    if menuOpen then return end
    menuOpen = true

    local menu = NativeUI.CreateMenu("Téléportation", "Choisissez une destination")

    for _, loc in ipairs(locations) do
        local item = NativeUI.CreateItem(loc.name, "Téléportez-vous à " .. loc.name)
        item.Activated = function(_, _)
            TeleportToLocation(loc.coords)
        end
        menu:AddItem(item)
    end

    -- Ajouter un bouton pour fermer le menu
    local closeItem = NativeUI.CreateItem("Fermer", "Quitter le menu")
    closeItem.Activated = function(_, _)
        menu:Close()
        menuOpen = false
    end
    menu:AddItem(closeItem)

    -- Afficher le menu
    menu:Visible(true)
end

-- Fonction pour téléporter le joueur
function TeleportToLocation(coords)
    SetEntityCoords(PlayerPedId(), coords.x, coords.y, coords.z, false, false, false, true)
    TriggerEvent('chat:addMessage', {args = {"Vous avez été téléporté à la destination choisie!"}})
end

-- Fonction pour dessiner du texte en 3D (utile pour afficher l'interaction)
function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(_World3dToScreen2d(x, y, z))
end
